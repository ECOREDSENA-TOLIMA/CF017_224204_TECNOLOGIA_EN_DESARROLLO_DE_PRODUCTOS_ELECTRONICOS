function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6hn0MkH2m1q":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

